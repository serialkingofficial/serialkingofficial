# Kodi addons developed by Ajay K

Latest repository zip file for Kodi is [repository.ajayk-1.1.zip](https://github.com/Vikassm73/AjaykRepo/raw/main/Zips/repository.ajayk-1.1.zip)

## Addons in the repository
|Icon|Name|Version|Release Date|Status|
|---|---|---|---|---|
|<img src="https://github.com/Vikassm73/AjaykRepo/blob/main/Zips/plugin.video.MXPlayer/icon.png" width="96">|MX Player|1.0.5|[2021-08-02](https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/plugin.video.MXPlayer/changelog.txt)|Working
|<img src="https://github.com/Vikassm73/AjaykRepo/blob/main/Zips/plugin.video.voot/icon.png" width="96">|Voot|2.0.2|[2021-04-08](https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/plugin.video.voot/changelog.txt)|Working
|<img src="https://github.com/Vikassm73/AjaykRepo/blob/main/Zips/plugin.video.zee5/icon.jpg" width="96">|Zee5|2.1.7|[2021-09-08](https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/plugin.video.zee5/changelog.txt)|Working
|<img src="https://github.com/Vikassm73/AjaykRepo/blob/main/Zips/plugin.video.sonyliv/icon.png" width="96">|Sonyliv|2.0.6|[2021-11-08](https://raw.githubusercontent.com/Vikassm73/AjaykRepo/main/Zips/plugin.video.sonyliv/changelog.txt)|Working

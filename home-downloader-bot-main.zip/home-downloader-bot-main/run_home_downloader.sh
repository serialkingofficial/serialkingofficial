#!/usr/bin/env bash

source "./venv/bin/activate"

python home_downloader.py
